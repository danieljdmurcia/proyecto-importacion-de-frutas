import os
from sqlmodel import SQLModel, create_engine, Session
from dotenv import load_dotenv

# Cargar variables de entorno desde .env (en local no hace daño)
load_dotenv()

# 1. Leer la URL de la base de datos (Render/Railway/Supabase)
DATABASE_URL = os.getenv("DATABASE_URL")

# 2. Si NO hay DATABASE_URL => usamos SQLite en local
if not DATABASE_URL:
    DATABASE_URL = "sqlite:///./app.db"
    connect_args = {"check_same_thread": False}
else:
    connect_args = {}

    # Normalizar prefijo por si viene como postgres://
    if DATABASE_URL.startswith("postgres://"):
        DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

    # Asegurar sslmode=require para conexiones remotas (Supabase, etc.)
    if DATABASE_URL.startswith("postgresql://") and "sslmode" not in DATABASE_URL:
        sep = "&" if "?" in DATABASE_URL else "?"
        DATABASE_URL = f"{DATABASE_URL}{sep}sslmode=require"

# 3. Crear el motor de conexión
engine = create_engine(
    DATABASE_URL,
    echo=True,           # pon False si no quieres ver los SQL en logs
    connect_args=connect_args,
)

# 4. Dependencia de sesión
def get_session():
    with Session(engine) as session:
        yield session

# 5. Inicializar tablas
def init_db():
    SQLModel.metadata.create_all(engine)
