from database import init_db

print("Creando tablas en Supabase...")
init_db()
print("Tablas creadas correctamente ✔")
